Quick Guide: Speedus - image version
==================================================

Copyright (c) 2015-, Torus Software Solutions. All rights reserved.

What is Speedus?
------------------------------
Speedus accelerates communications between applications running in the same
machine (intraserver comms) and optimizes transfers between applications across
different machines in a LAN (interserver comms). This document will show you how
to setup Speedus in a Linux box as well as execute a few quick benchmarks to test
the benefits of Speedus.

More information about our products at http://www.torusware.com

Step-by-step guide
------------------
You will find Speedus already installed in the '/opt/torusware/speedus' directory.
Also, we provide a 'speedus' script in '/usr/bin' which you can prefix to any
given application to execute it running with Speedus acceleration, as we show in
the following examples.

- How to test Speedus performance benefits on a native socket-based C code?

  # Running NetPIPE with system sockets
     $ NPtcp &
     $ NPtcp -h localhost

   # Running NetPIPE with Speedus (you should see a message indicating that Speedus has been loaded)
     $ speedus NPtcp &
     $ speedus NPtcp -h localhost

- How to test Speedus performance benefits on a socket-based Java code?

   # Change the directory to where the Java Benchmark is located
     $ cd /opt/torusware/speedus/benchmarks/NetPIPE-Java

   # Running Java NetPIPE with system sockets
     $ java -cp $PWD/netpipe.jar benchmarking.NetPIPE TCP -p 0 -q -recv -host localhost &
     $ java -cp $PWD/netpipe.jar benchmarking.NetPIPE TCP -p 0 -q -send -host localhost

   # Running Java NetPIPE with Speedus (you should see a message indicating that Speedus has been loaded)
     $ speedus java -cp $PWD/netpipe.jar benchmarking.NetPIPE TCP -p 0 -q -recv -host localhost &
     $ speedus java -cp $PWD/netpipe.jar benchmarking.NetPIPE TCP -p 0 -q -send -host localhost

- As you can see, using speedus is non-intrusive and easy, just type 'speedus' before your application:
     $ speedus /your/app [your-app-parameters]

If you have any trouble with the installation or the tests, please reach us at speedus@torusware.com
