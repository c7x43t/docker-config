# Quick Guide: Speedus

Copyright (c) 2015-, Torus Software Solutions. All rights reserved.

## What is Speedus?

Speedus accelerates communications between applications running in the
same machine (intraserver comms) and optimizes transfers between applications
across different machines in a LAN (interserver comms). This document will show
you how to setup Speedus in a Linux box as well as execute a few quick benchmarks
to test the benefits of Speedus.

More information about our products at http://www.torusware.com

## Linux HowTo

### Installation & Setup

Uncompress the Speedus ZIP file and set `SPEEDUS_HOME` to the Speedus
installation directory (in this example with version `speedus-bYYYYMMDD-linux`)
```bash
unzip speedus-latest-linux.zip
export SPEEDUS_HOME=$PWD/speedus-bYYYYMMDD-linux
# Or, if the installation directory is not the current directory
export SPEEDUS_HOME=/PATH/TO/DIR/speedus-bYYYYMMDD-linux
```

### How to test Speedus performance benefits on a native socket-based C code?

First change the directory and compile the NetPIPE-C benchmark
```bash
cd $SPEEDUS_HOME/benchmarks/NetPIPE-C
make tcp
```

Running NetPIPE with system sockets
```bash
./NPtcp &
./NPtcp -h localhost
```

Running NetPIPE with Speedus (you should see a message indicating that Speedus has been loaded)
```bash
LD_LIBRARY_PATH=$SPEEDUS_HOME/lib:$SPEEDUS_HOME/lib32 LD_PRELOAD=libspeedus.so ./NPtcp &
LD_LIBRARY_PATH=$SPEEDUS_HOME/lib:$SPEEDUS_HOME/lib32 LD_PRELOAD=libspeedus.so ./NPtcp -h localhost
```

Alternatively, if you prefer, you can define an alias for more clarity
```bash
alias speedus='LD_LIBRARY_PATH=$SPEEDUS_HOME/lib:$SPEEDUS_HOME/lib32 LD_PRELOAD=libspeedus.so'
speedus ./NPtcp &
speedus ./NPtcp -h localhost
```

### How to test Speedus performance benefits on a socket-based Java code?

Change the directory to where the Java Benchmark is located
```bash
cd $SPEEDUS_HOME/benchmarks/NetPIPE-Java
```

Running Java NetPIPE with system sockets
```bash
java -Djava.net.preferIPv4Stack=true -cp $PWD/netpipe.jar benchmarking.NetPIPE TCP -p 0 -q -recv -host localhost &
java -Djava.net.preferIPv4Stack=true -cp $PWD/netpipe.jar benchmarking.NetPIPE TCP -p 0 -q -send -host localhost
```

Running Java NetPIPE with Speedus (you should see a message indicating that Speedus has been loaded)
```bash
LD_LIBRARY_PATH=$SPEEDUS_HOME/lib:$SPEEDUS_HOME/lib32 LD_PRELOAD=libspeedus.so java -Djava.net.preferIPv4Stack=true -cp $PWD/netpipe.jar benchmarking.NetPIPE TCP -p 0 -q -recv -host localhost &
LD_LIBRARY_PATH=$SPEEDUS_HOME/lib:$SPEEDUS_HOME/lib32 LD_PRELOAD=libspeedus.so java -Djava.net.preferIPv4Stack=true -cp $PWD/netpipe.jar benchmarking.NetPIPE TCP -p 0 -q -send -host localhost
```

Or if you have set the alias as explained before
```bash
speedus java -Djava.net.preferIPv4Stack=true -cp $PWD/netpipe.jar benchmarking.NetPIPE TCP -p 0 -q -recv -host localhost &
speedus java -Djava.net.preferIPv4Stack=true -cp $PWD/netpipe.jar benchmarking.NetPIPE TCP -p 0 -q -send -host localhost
```

If you have any trouble with the installation or the tests, please reach us at [speedus@torusware.com](mailto:speedus@torusware.com)
